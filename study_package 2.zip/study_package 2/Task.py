import json
from datetime import datetime, timedelta
import zipfile
import os

def create_placeholder_files():
    print("[INFO] Creating placeholder files...")
    info_content = {
        "contactEmail": "anna.fischer@uni-goettingen.de",
        "currentProject": "NewAppStudy",
        "sendServerAddress": "anapquest.psych.uni-goettingen.de",
        "registerServerAddress": "anapquest.psych.uni-goettingen.de",
        "infoText": "This is the new emotion regulation study. \nTry it out."
    }
    
    questionnaires_content = {
        "MainQuestionnaire": {
            "questType": "simple",
            "panes": {
                "GlobalMood": {
                    "paneName": "GlobalMood",
                    "parameters": {
                        "nextPanes": ["PositiveOrNegative"],
                        "isStart": True
                    }
                },
                "PositiveOrNegative": {
                    "paneName": "PositiveOrNegative",
                    "parameters": {
                        "nextPanes": ["LabelEmotionPositive", "LabelEmotionNegative"]
                    }
                },
                "WhoWasWithYou": {
                    "paneName": "WhoWasWithYou",
                    "parameters": {
                        "nextPanes": [],
                        "isEnd": True
                    }
                }
            }
        },
        "EndOfDay": {
            "questType": "simple",
            "panes": {
                "WellBeing": {
                    "paneName": "WellBeing",
                    "parameters": {
                        "nextPanes": [],
                        "isEnd": True
                    }
                }
            }
        },
        "Empty": {
            "questType": "simple",
            "panes": {
                "WellBeing": {
                    "paneName": "Empty",
                    "parameters": {
                        "nextPanes": [],
                        "isStart": True,
                        "isEnd": True
                    }
                }
            }
        }
    }
    
    with open('info.json', 'w') as f:
        json.dump(info_content, f, indent=2)
        print("[INFO] info.json created successfully.")
    
    with open('questionnaires.json', 'w') as f:
        json.dump(questionnaires_content, f, indent=2)
        print("[INFO] questionnaires.json created successfully.")
    
    panes_content = {}
    with open('panes.json', 'w') as f:
        json.dump(panes_content, f, indent=2)
        print("[INFO] panes.json created successfully.")

def create_schedule(start_date_str):
    print(f"[INFO] Creating schedule starting from {start_date_str}...")
    start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
    
    time_windows = [
        ('08:00:00.000', '11:00:00.000'),  # Morning: 8-11 AM
        ('13:00:00.000', '16:00:00.000'),  # Afternoon: 1-4 PM
        ('18:00:00.000', '21:00:00.000')   # Evening: 6-9 PM
    ]
    
    schedule = {
        "scheduleType": "simpleSchedule",
        "quests": {}
    }
    
    for week in range(1, 3):  # 2 weeks
        for day in range(7):  # 7 days per week
            current_date = start_date + timedelta(days=(week-1)*7 + day)
            day_name = current_date.strftime('%A').lower()
            
            for quest_num, (start_time, end_time) in enumerate(time_windows, 1):
                quest_key = f"week{week}-{day_name}-quest{quest_num}"
                quest_date = current_date.strftime('%Y-%m-%d')
                
                schedule["quests"][quest_key] = {
                    "questName": "MainQuestionnaire" if quest_num < 3 else "EndOfDay",
                    "from": f"{quest_date} {start_time}",
                    "to": f"{quest_date} {end_time}"
                }
                
                stop_key = f"{quest_key}-stop"
                schedule["quests"][stop_key] = {
                    "questName": "Empty",
                    "from": f"{quest_date} {end_time}",
                    "to": f"{quest_date} {end_time}"
                }
    
    print("[INFO] Schedule creation complete.")
    return schedule

def create_zip_package(start_date):
    print("[INFO] Creating zip package...")
    schedule = create_schedule(start_date)
    
    with open('schedule.json', 'w') as f:
        json.dump(schedule, f, indent=2)
        print("[INFO] schedule.json created successfully.")
    
    create_placeholder_files()
    
    with zipfile.ZipFile('study_package.zip', 'w') as zipf:
        for filename in ['schedule.json', 'info.json', 'panes.json', 'questionnaires.json']:
            if os.path.exists(filename):
                zipf.write(filename)
                print(f"[INFO] Added {filename} to the zip package.")
            else:
                print(f"[WARNING] {filename} not found in current directory.")

def main():
    print("[INFO] Welcome to the Study Package Generator!")
    while True:
        start_date = input("Enter start date (YYYY-MM-DD): ")
        try:
            datetime.strptime(start_date, '%Y-%m-%d')
            print("[INFO] Valid date format detected.")
            break
        except ValueError:
            print("[ERROR] Invalid date format. Please use YYYY-MM-DD format.")
    
    create_zip_package(start_date)
    print(f"\n[INFO] Package created successfully: study_package.zip")

if __name__ == "__main__":
    main()
